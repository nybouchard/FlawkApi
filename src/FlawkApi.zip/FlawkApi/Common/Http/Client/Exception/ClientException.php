<?php

namespace FlawkApi\Common\Http\Client\Exception;

use FlawkApi\Common\Exception\Exception;

/**
 * ClientException, exception class
 */

class ClientException extends Exception {

}